<?php

class FormValidation
{
    private $formID = null;
    private $formIDName = null;
    private $POST = null;

    public function __construct($formID, $POST = false, $formIDName="formID")
    {
        $this->formID = $formID;
        $this->POST = $POST ? $POST : $_POST;
        $this->formIDName = $formIDName;
        return $this;
    }

    public function value($name, $sanitize=true)
    {
        if ( isset($this->POST[$name]) ) {
            return $sanitize ? htmlspecialchars($this->POST[$name], ENT_QUOTES, "UTF-8") : $this->POST[$name];
        }
        return "";
    }

    public function submitted()
    {
        if ( !empty($this->POST) && $this->value($this->formIDName, false) === $this->formID ) {
            return true;
        }
        return false;
    }

    public function validate($nameArr=array()) {
        if ( !$this->submitted() ) return $this;

        foreach ( $nameArr as $name => $validationFunction ) {
            $error = call_user_func_array($validationFunction, array($this->value($name, false), $this));

            if ( is_string($error) ) {
                $this->errors[$name] = $error;
            }
        }
        return $this;
    }


    public function error($name)
    {
        return isset($this->errors[$name]) ? $this->errors[$name] : "";
    }

    public function addError($name, $error)
    {
        if ( !isset($this->errors[$name]) ) {
            $this->errors[$name] = $errors;
        }
        return $this;
    }

    public function errorInForm()
    {
        return empty($this->errors) ? false : true;
    }

    public function success()
    {
        return $this->submitted() && !$this->errorInForm();
    }
}

$register = new FormValidation("register");

$register->validate(array(

    "username" => function($value) {
    if ( empty($value) ) {
        return "You Must Provide A Username". PHP_EOL; //return
      }
    },

    "email" => function($value) {
        if ( empty($value) ) {
            return "You Must Provide An E-Mail Address"; //return
        }
        if ( !filter_var($value, FILTER_VALIDATE_EMAIL) ) {
            return "You Must Provide A Valid E-Mail Address"; //return
      }
    },

    "password" => function($value){
        if ( empty($value) ) {
            return "You Must Provide A Password"; //return
        }
    },

    "confirmpassword" => function($value, $register){
        if ( empty($value) ) {
            return "You Must Confirm Your Password"; //return
        }
        if ( $value!==$register->value("password") ) {
            return "Passwords Did Not Match"; //return
        }
    }
    ));
        if ( $register->success() ) {
          die("you have successfully registred");
          exit;
        }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

<form  action="<?=$_SERVER['PHP_SELF']?>" method="post">

  <input type="hidden" name="formID" value="register">

  <?=$register->error("username")?><br>
  username: <input type="text" name="username" value="<?=$register->value("username")?>" placeholder="username"> <br>

  <?=$register->error("email")?><br>
  email: <input type="text" name="email" value="<?=$register->value("email")?>" placeholder="email"> <br>

  <?=$register->error("password")?><br>
  password: <input type="password" name="password" placeholder="password"> <br>

  <?=$register->error("confirmpassword")?><br>
  confirm password: <input type="password" name="confirmpassword" placeholder="сonfirm password"> <br>
  <input type="submit" value="register" >

</form>

  </body>
</html>
